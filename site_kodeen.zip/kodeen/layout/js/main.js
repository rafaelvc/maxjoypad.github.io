main_navbar	  = $("#main-navbar").height();
kodeen_navbar = ($("#kodeen-navbar").height() !== undefined ? $("#kodeen-navbar").height() : 0);

(function($) {
"use strict";

$('a.scroll-to[href*="#"]').click(function()
{
	if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname)
	{
		var target  = $(this.hash);

		target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');

		if (target.length) {
			$('html, body').animate({
				scrollTop: (target.offset().top - (main_navbar+kodeen_navbar))
			}, 1000);

			return false;
		}
	}
});

$('.scroll-to').click(function() {
	$('.navbar-collapse').collapse('hide');
});

$('body').scrollspy({
	target: '#main-navbar',
	offset: (main_navbar+kodeen_navbar)+50
});

})(jQuery);

$('.carousel').carousel({
  interval: 9000,
  pause: false
});