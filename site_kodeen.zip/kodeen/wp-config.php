<?php

define('ALLOW_UNFILTERED_UPLOADS', true);

/* )Dl%9Caj@b($J)Vgs( */
/**
 * As configurações básicas do WordPress
 *
 * O script de criação wp-config.php usa esse arquivo durante a instalação.
 * Você não precisa usar o site, você pode copiar este arquivo
 * para "wp-config.php" e preencher os valores.
 *
 * Este arquivo contém as seguintes configurações:
 *
 * * Configurações do MySQL
 * * Chaves secretas
 * * Prefixo do banco de dados
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/pt-br:Editando_wp-config.php
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar estas informações
// com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define('DB_NAME', 'u324871529_gejem');

/** Usuário do banco de dados MySQL */
define('DB_USER', 'u324871529_patyp');

/** Senha do banco de dados MySQL */
define('DB_PASSWORD', 'devkodeen2017');

/** Nome do host do MySQL */
define('DB_HOST', 'localhost');

/** Charset do banco de dados a ser usado na criação das tabelas. */
define('DB_CHARSET', 'utf8mb4');

/** O tipo de Collate do banco de dados. Não altere isso se tiver dúvidas. */
define('DB_COLLATE', '');

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las
 * usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org
 * secret-key service}
 * Você pode alterá-las a qualquer momento para invalidar quaisquer
 * cookies existentes. Isto irá forçar todos os
 * usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'OdD3QUS9|nm^U> :|@q>8R~BN5cQyl.=grff XwLP|ga4~sX::oJwf9v4qI:@Y6n');
define('SECURE_AUTH_KEY',  '4^yY|-|&X!axh9Pw*e?U43?^CWUO-<a*4wv%OVQoK[+Q_y?S0/Y-6VE-bN7f{x;z');
define('LOGGED_IN_KEY',    ')~>}*or.)0bApGs@k%f}-J-}<@pv(}JWH$j$jPn:Rx6P2YA2#p,A@BIE{lK;H>7(');
define('NONCE_KEY',        'lXDi`R]FgT03t[,HLC:!sH5.EysR<TRHNB`cP}u!;jsm;<z+xxA1A)+Uu<:R>H$)');
define('AUTH_SALT',        'D%4r){YvmZ]W|y5Dc:eP|CNFgLTOQA9{-?K*FF}zK(OI}Q2&8OCBkq,Wov S+rc2');
define('SECURE_AUTH_SALT', 'fl Pjn73!i;i_/0#.yt&h#:x2-CVVZTEmyaCDDqz-<ylExwxR@9MLj6FJS!t%><|');
define('LOGGED_IN_SALT',   ')D[6qxMc->h4-5H6`N7Ny$Wh@K/-4@X#p)w9iw~;s[|x}e?&N5/v<74hp`$%?.?,');
define('NONCE_SALT',       '?v-B9fYN&q&YQ!/u.i[quE44T^sRv63S}5<  WvBM8=]`#uP&@6qB`D{vy~%<WYD');

/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der
 * um prefixo único para cada um. Somente números, letras e sublinhados!
 */
$table_prefix  = 'wp_';

/**
 * Para desenvolvedores: Modo de debug do WordPress.
 *
 * Altere isto para true para ativar a exibição de avisos
 * durante o desenvolvimento. É altamente recomendável que os
 * desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 *
 * Para informações sobre outras constantes que podem ser utilizadas
 * para depuração, visite o Codex.
 *
 * @link https://codex.wordpress.org/pt-br:Depura%C3%A7%C3%A3o_no_WordPress
 */
define('WP_DEBUG', false);

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Configura as variáveis e arquivos do WordPress. */
require_once(ABSPATH . 'wp-settings.php');
